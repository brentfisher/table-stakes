# Table Stakes — After Hours recap

Open `http://127.0.0.1:5194/recap.html` with this folder served over HTTP (`npm start`). The menu suite still includes the neon start menu at `start.html` and the setup preview at `index.html`. No package installation, external CDN, account or game server is needed.

## Experience

The opening highlights give most of the space to the best-selling food model and the most actionable management tip. Bright white cards, large condensed headings and orange coaching accents follow the pantry/setup preview. Each category drops in independently with a short settling animation.

- **The highlights:** outcome, the 3D tomato chef reaction, final scores, prominent best seller, smaller supporting dishes and the lead tip.
- **Next shift:** browse recorded takeaways, inspect evidence, add useful moves to a game plan, and download that plan as text.
- **Menu stars:** a larger interactive 3D showcase. Select another dish to inspect it. Sales ties are explicitly labeled, and fastest fulfillment is kept distinct from sales volume and margin.
- **The numbers:** net profit, revenue, expenses, service metrics and a detailed comparison dialog. Additional management detail is expandable.
- **Arrange board:** drag category handles to swap panels; arrow buttons provide a keyboard/touch alternative. Reset order restores the initial board.
- **Replay reveal:** replays the staggered entrance and, on a win, the short fireworks sequence.
- **Motion:** switches off card movement, character animation and fireworks. The system reduced-motion preference is respected initially.

The default PDF loss uses a frowning tomato chef with a drooping hat and animated tear. The illustrative win uses a smiling, bouncing version and a short colored firework sequence with round particles and trails. A draw preview is included as well.

## Source and data accuracy

`data/recap-match.json` transcribes the visible figures from `Rival Restaurant-recap.pdf`. The original PDF is not redistributed in the bundle. The main values are read as recorded: score 32.7 versus 138.5, revenue $174.60, expenses $544.40, net profit −$369.80, and temporary labor $38 for zero recorded tasks.

Caesar Salad and Smash Burger both sold six. The salad appears first because it is first in the supplied ranking; it is labeled a co-best seller, and the burger can take the spotlight too. Espresso's fastest fulfillment does not make it the best seller.

Staff and promotion costs are already part of total expenses. Coaching describes recorded costs and observations, without claiming that a single cost caused the loss or that promotion-window revenue was caused by that promotion. The PDF truncates later turning points and does not show score-component values; those missing figures are not invented.

The win/draw fixtures are **illustrative sample data**, clearly labeled in the menu. Switching to them leaves the original fixture unchanged. This preview does not simulate a new match or modify the live game. Saved notes and arrangement last for the page session; downloaded notes can be retained independently.

## Integration

- `src/recap-model.js`: pure presentation helpers for a `match_complete`-style message and player ID, including outcome, stable best-seller ranking, tie labels and management takeaways.
- `src/recap.js`: HTML controls, category transitions, arrangement, scorecard dialog and game-plan export. Replace the local fixture load with the game's received result payload when integrating. The demo selector is preview-only.
- `src/recap-scene.js`: Three.js mascot, GLB displays and finite fireworks. Reuses the pantry showroom helpers in `src/scene.js`, a single WebGL renderer and scissored viewports.
- `recap.css`: white presentation, staggered drop transitions, responsive layout, focus indicators and reduced-motion treatment.

The current model adapter handles a missing/unscored result distinctly from a draw. Real server validation and result generation remain authoritative. `index.html` is the next-shift setup preview; the footer does not submit a rematch request.

## Verified

`npm test` runs the original setup and neon checks plus recap tests for PDF values, tied sales, ranking, conditional labor advice, negative-profit formatting, demo isolation, and draw/unscored/empty-sale cases.

Browser checks covered loss and win rendering, GLB displays, mascot reactions, fireworks, motion controls, dragging panels to a new order, arrow-based reordering, saving a tip, its evidence dialog, selecting the other co-best seller, opening the larger dish view, and the detailed financial scorecard. No browser warning/error logs were reported during those checks.

## Screenshot handoff

`story-screenshots/` includes 10 numbered PNG captures of the outcome states, coaching, evidence, dish spotlight, financial panels, detailed scorecard, rearranged board, and a fireworks frame. Open `story-screenshots/index.html` for a visual gallery or `story-screenshots/SCREENSHOT-INDEX.md` for story statements and suggested acceptance criteria. All captures use the existing browser viewport; focused panels are scrolled into view.
