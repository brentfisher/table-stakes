import {isAddonCategory, priceBoundsFor, isPriceInRange, inventoryCost, defaultInventoryAllocation} from '../shared/schemas/setup-rules.js';
export function createSetup(data) {
  const s={step:0,confirmed:-1,selected:[],prices:{},upgrade:null,staff:{cook_1:'prep',server_1:'dining_room'},policy:null,policyDish:null,inventory:{},stockInitialized:false,ready:false};
  const dish=id=>data.dishes.find(d=>d.id===id);
  const chosen=()=>s.selected.map(dish);
  const upgrade=()=>data.upgrades.find(u=>u.id===s.upgrade);
  const cost=()=>inventoryCost(s.inventory,data.ingredients)??Infinity;
  const remaining=()=>Math.round((600-(upgrade()?.cost??0)-cost())*100)/100;
  const invalidate=step=>{s.confirmed=Math.min(s.confirmed,step-1);s.ready=false;};
  const toggle=id=>{
    const d=dish(id);if(!d)return 'Unknown dish.';
    if(s.selected.includes(id)){s.selected=s.selected.filter(x=>x!==id);if(s.policyDish===id)s.policyDish=null;}
    else{const addon=isAddonCategory(d.category);if(chosen().filter(x=>isAddonCategory(x.category)===addon).length>=(addon?2:3))return addon?'Your two add-on slots are full.':'Your three main slots are full. Remove one to swap.';s.selected.push(id);s.prices[id]??=d.suggestedPrice;}
    const used=new Set(chosen().flatMap(d=>Object.keys(d.ingredients)));for(const key of Object.keys(s.inventory))if(!used.has(key))delete s.inventory[key];
    invalidate(0);return null;
  };
  const validate=step=>{
    if(chosen().filter(d=>!isAddonCategory(d.category)).length!==3)return 'Choose exactly 3 mains to continue.';
    if(chosen().filter(d=>isAddonCategory(d.category)).length>2)return 'Choose up to 2 add-ons.';
    if(step>=1){
      if(!['prep','grill','oven','plating'].includes(s.staff.cook_1)||!['dining_room','pass','host_stand'].includes(s.staff.server_1))return 'Assign both crew members to a valid post.';
      if(s.upgrade&&!upgrade())return 'Choose a valid opening upgrade.';
      if(s.policy&&!data.policies.some(p=>p.id===s.policy))return 'Choose a valid policy.';
      if(s.policy==='house_special'&&!s.selected.includes(s.policyDish))return 'Choose a dish for your House Special.';
    }
    if(step>=2){
      for(const d of chosen())if(!isPriceInRange(d,s.prices[d.id]))return `Set a valid price for ${d.name}.`;
      for(const [id,n] of Object.entries(s.inventory))if(!data.ingredients[id]||!Number.isInteger(n)||n<0||n>80)return 'Stock must be whole units from 0 to 80.';
      if(remaining()<0)return 'Over budget. Reduce stock or change your upgrade.';
    }return null;
  };
  const recommend=()=>{s.inventory=defaultInventoryAllocation(chosen(),data.ingredients,{cash:600-(upgrade()?.cost??0),cashShare:.6,servings:45,maxUnitsPerIngredient:80});s.stockInitialized=true;invalidate(2);};
  const next=()=>{const err=validate(s.step);if(err)return err;s.confirmed=s.step;if(s.step<2){s.step++;if(s.step===2&&!s.stockInitialized)recommend();}else s.ready=true;return null;};
  const payload=()=>({menu:chosen().filter(d=>!isAddonCategory(d.category)).map(d=>({dishId:d.id,price:s.prices[d.id]})),addons:chosen().filter(d=>isAddonCategory(d.category)).map(d=>({dishId:d.id,price:s.prices[d.id]})),startingUpgradeId:s.upgrade,staffAssignments:{...s.staff},startingInventory:{...s.inventory},policyId:s.policy,policyDishId:s.policy==='house_special'?s.policyDish:null});
  return {s,dish,chosen,upgrade,cost,remaining,toggle,validate,recommend,next,payload,invalidate,priceBoundsFor};
}
