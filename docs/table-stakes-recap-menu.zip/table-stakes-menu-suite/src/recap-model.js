export const money = value => Number.isFinite(value) ? `${value<0?'−':''}$${Math.abs(value).toFixed(2)}` : '—';
export const label = id => String(id??'').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());
export function dishLeaders(result){
 const dishes=(result?.bestSellingDishes??[]).filter(d=>Number.isFinite(d.count)&&d.count>0).map((d,i)=>({...d,sourceIndex:i})).sort((a,b)=>b.count-a.count||a.sourceIndex-b.sourceIndex);
 return {dishes,featured:dishes[0]??null,tied:dishes.filter(d=>d.count===dishes[0]?.count).map(d=>d.dishId)};
}
export function recapView(match,playerId){
 const self=match?.results?.[playerId]??{},rivalId=Object.keys(match?.results??{}).find(id=>id!==playerId),rival=match?.results?.[rivalId]??{};
 const scored=Number.isFinite(self.score)&&Number.isFinite(rival.score);
 const outcome=!scored?'unscored':match.winnerPlayerId===null?'draw':match.winnerPlayerId===playerId?'win':'loss';
 return {self,rival,outcome,scored,...dishLeaders(self),tips:coachNotes(self)};
}
export function coachNotes(result){
 const ledger=result?.managerLedger,notes=[];
 const labor=ledger?.labor;
 if(labor?.laborExpenses>0&&labor.taskCompletions===0){notes.push({id:'labor',label:'TEMPORARY STAFF',title:'Your temp staff ate into profit.',punch:`${money(labor.laborExpenses)} spent.\n0 recorded tasks.`,observation:`${money(labor.hireFees)} in hire fees and ${money(labor.wagesPaid)} in wages. This cost is already included in your expenses.`,action:'Redirect your dining-room crew first. Hire extra help for a bottleneck they can actually clear.',evidence:ledger.insights?.find(i=>i.category==='labor')?.observation??'No task completions were recorded for temporary staff.',tone:'amber'});}
 for(const insight of ledger?.insights??[]){if(notes.some(n=>n.id===insight.category))continue;notes.push({id:insight.category,label:insight.category==='seating_service'?'DINING ROOM':insight.category==='specials'?'PROMOTIONS':label(insight.category).toUpperCase(),title:insight.category==='seating_service'?'Clear tables. Then chase the crowd.':insight.category==='specials'?'A busy queue isn’t a payday.':'One move for the next shift.',punch:insight.category==='seating_service'?'Make room\nbefore making noise.':insight.category==='specials'?`${money(result.specialExpenses)} on offers.\nCheck the payoff.`:insight.observation,observation:insight.observation,action:insight.recommendation,evidence:insight.category==='specials'?'These are observed promotion windows, not proof of extra revenue caused by an offer.':insight.observation,tone:'blue'});}
 if(!notes.length)notes.push({id:'steady',label:'NEXT SHIFT',title:'Keep the good shift going.',punch:'Repeat what worked.\nWatch the next bottleneck.',observation:'No additional management recommendation was recorded for this match.',action:'Keep an eye on queues, stock and labor before adding another promotion.',evidence:'General planning suggestion; no extra match cause is claimed.',tone:'blue'});
 return notes;
}
export function winDemo(original){
 const fixture=structuredClone(original),self=fixture.match.results[fixture.playerId];fixture.source='Illustrative win · sample data';fixture.match.winnerPlayerId=fixture.playerId;
 Object.assign(self,{score:186.4,revenue:612,expenses:386,netProfit:226,laborExpenses:0,guestsServed:24,averageSatisfaction:88,averageWaitTimeMs:12400,customersLostToRival:9,eventPerformance:{eventObjectiveFraction:.94,criticFailures:0},bestSellingDishes:[{dishId:'smash_burger',count:18,revenue:252},{dishId:'caesar_salad',count:11,revenue:132},{dishId:'espresso',count:8,revenue:40}],bestDish:{dishId:'espresso',count:8,avgFulfillmentMs:4000},customerSegmentBreakdown:{office_worker:16,event_fan:5,tourist:3}});
 self.managerLedger={labor:{laborExpenses:0,hireFees:0,wagesPaid:0,taskCompletions:0},specials:[],constraints:[],insights:[{category:'seating_service',observation:'Your average wait was 12.4 seconds and average satisfaction was 88.',recommendation:'Keep dining-room coverage in place before you expand the menu or run another promotion.'}]};fixture.match.turningPoints=[];fixture.match.decidingSegment=null;return fixture;
}
