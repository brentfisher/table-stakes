import * as T from 'three';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';
export const SPARK_COLORS = [0xffb34f, 0x5ce5ed, 0xff719c, 0xffe4a0, 0xb59aff];
export const nextSparkDelay = () => 3 + Math.random() * 2;
/** Self-contained sign, scene, bloom and pooled contour-emitted sparks. No DOM menu dependencies. */
export class NeonRestaurantSign {
 constructor(container,{wordmarksUrl=new URL('../vendor/fonts/title-wordmarks.json?v=diner-4',import.meta.url).href,reducedMotion=false,sparks=true,bloom=0.6}={}){
  this.container=container;this.options={reducedMotion,sparks,bloom};this.emitters=[];this.cursor=0;this.time=0;this.nextBurst=nextSparkDelay();this.pointer=new T.Vector2();this.disposed=false;
  this.renderer=new T.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));this.renderer.toneMapping=T.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1;this.renderer.setClearColor(0x0c151c,0);container.appendChild(this.renderer.domElement);this.renderer.domElement.setAttribute('aria-hidden','true');
  this.scene=new T.Scene();this.camera=new T.PerspectiveCamera(35,1,.1,100);this.camera.position.set(.2,.4,18.4);this.camera.lookAt(0,0,0);this.scene.add(new T.HemisphereLight(0x90b9c8,0x1a1210,1.1));
  this.warm=new T.PointLight(0xff852f,65,15,2);this.warm.position.set(-2,1,2);this.scene.add(this.warm);const cool=new T.PointLight(0x37dce9,45,14,2);cool.position.set(3,-2,2);this.scene.add(cool);
  this.root=new T.Group();this.scene.add(this.root);this.root.rotation.y=-.045;this.buildFacade();this.buildParticles();
  this.composer=new EffectComposer(this.renderer);this.composer.addPass(new RenderPass(this.scene,this.camera));this.bloomPass=new UnrealBloomPass(new T.Vector2(800,600),bloom,.42,1.05);this.composer.addPass(this.bloomPass);this.composer.addPass(new OutputPass());
  this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(container);this.resize();this.last=0;this.tick=this.tick.bind(this);this.renderer.setAnimationLoop(this.tick);
  this.ready=new T.FileLoader().setResponseType('json').loadAsync(wordmarksUrl).then(wordmarks=>{if(this.disposed)return;this.buildTitle(wordmarks);this.nextBurst=this.time+nextSparkDelay();container.classList.add('sign-ready');});
 }
 material(color,metalness=.0,roughness=.6){return new T.MeshStandardMaterial({color,metalness,roughness});}
 box(w,h,d,x,y,z,material){const m=new T.Mesh(new T.BoxGeometry(w,h,d),material);m.position.set(x,y,z);this.root.add(m);return m;}
 tube(points,radius,material,smooth=true){let curve;if(smooth)curve=new T.CatmullRomCurve3(points);else{curve=new T.CurvePath();for(let i=1;i<points.length;i++)curve.add(new T.LineCurve3(points[i-1],points[i]));}const m=new T.Mesh(new T.TubeGeometry(curve,Math.max(10,points.length*2),radius,6,false),material);this.root.add(m);return m;}
 buildFacade(){
  const brickGeo=new T.BoxGeometry(.84,.31,.16),brickMat=this.material(0x283038,.1,.87);const bricks=new T.InstancedMesh(brickGeo,brickMat,28*21);const dummy=new T.Object3D();let n=0;for(let y=0;y<21;y++)for(let x=0;x<28;x++){dummy.position.set((x-14)*.9+(y%2)*.45,(y-10)*.36,-.61);dummy.updateMatrix();bricks.setMatrixAt(n,dummy.matrix);const col=new T.Color(0x333940).multiplyScalar(.6+((x*17+y*11)%13)/25);bricks.setColorAt(n++,col);}this.root.add(bricks);
  this.box(10.4,5.7,.22,0,0,-.27,this.material(0x123d42,.35,.38));this.box(10.62,.075,.3,0,2.89,-.1,this.material(0x7a7060,.8,.3));this.box(10.62,.075,.3,0,-2.89,-.1,this.material(0x7a7060,.8,.3));
  this.neonOrange=new T.MeshBasicMaterial({color:new T.Color(1,.19,.022).multiplyScalar(2.5),toneMapped:false});this.neonCream=new T.MeshBasicMaterial({color:new T.Color(1,.71,.35).multiplyScalar(2),toneMapped:false});this.neonCyan=new T.MeshBasicMaterial({color:new T.Color(.025,.72,1).multiplyScalar(1.8),toneMapped:false});
  // Local HDR intensities brighten the lettering without washing out the whole sign.
  this.neonPink=new T.MeshBasicMaterial({color:new T.Color(1,.045,.32).multiplyScalar(5.5),toneMapped:false});
  this.neonScriptCore=new T.MeshBasicMaterial({color:new T.Color(1,.72,.25).multiplyScalar(3.2),toneMapped:false});
  this.neonStakes=new T.MeshBasicMaterial({color:new T.Color(1,.25,.055).multiplyScalar(6.5),toneMapped:false});
  this.neonRedPink=new T.MeshBasicMaterial({color:new T.Color(1,.035,.16).multiplyScalar(8),toneMapped:false});
  const border=[];for(let i=0;i<=160;i++){let a=i/160*Math.PI*2;const cx=Math.cos(a),sy=Math.sin(a);border.push(new T.Vector3(Math.sign(cx)*Math.pow(Math.abs(cx),.28)*4.92,Math.sign(sy)*Math.pow(Math.abs(sy),.35)*2.48,.02));}this.tube(border,.055,this.neonCyan);
  const screwMat=this.material(0x77746a,.9,.35);for(const x of [-5.03,5.03])for(const y of [-2.64,2.64]){const m=new T.Mesh(new T.SphereGeometry(.045,12,8),screwMat);m.position.set(x,y,-.1);this.root.add(m);}
  const rail=this.material(0x252c30,.7,.4);for(const x of [-3.7,3.7])this.box(.065,2,.12,x,3.55,-.35,rail);
  for(let i=0;i<17;i++){const x=-5.1+i*.64,y=3.35+Math.cos(x*.4)*.12;const bulb=new T.Mesh(new T.SphereGeometry(.045,12,8),this.neonCream);bulb.position.set(x,y,0);this.root.add(bulb);}this.tube(Array.from({length:30},(_,i)=>{let x=-5.4+i/29*10.8;return new T.Vector3(x,3.4+Math.cos(x*.4)*.12,-.04);}),.015,rail);
  // Continue the warm marquee bulbs around both sides of the sign.
  const sideBulbGeometry=new T.SphereGeometry(.045,12,8);
  for(const side of [-1,1]){
   for(let i=0;i<10;i++){const bulb=new T.Mesh(sideBulbGeometry,this.neonCream);bulb.position.set(side*5.35,2.72-i*.64,0);bulb.name=`side-marquee-${side}-${i}`;this.root.add(bulb);}
   this.tube([new T.Vector3(side*5.25,3.34,-.04),new T.Vector3(side*5.35,3.12,-.04),new T.Vector3(side*5.35,-3.14,-.04)],.015,rail);
  }
  // A continuous, hand-drawn neon flourish replaces the two bottom brackets.
  const flourish=[[-4.4,-3.42],[-3.8,-3.15],[-3,-3.54],[-2.1,-3.27],[-1.15,-3.57],[-.2,-3.31],[.65,-3.13],[1.65,-3.52],[2.65,-3.23],[3.55,-3.49],[4.4,-3.16]].map(([x,y])=>new T.Vector3(x,y,.08));
  const squiggle=this.tube(flourish,.047,this.neonRedPink);squiggle.name='pink-red-neon-squiggle';
  const spill=new T.PointLight(0xff286a,24,7,2);spill.position.set(0,-3.15,.65);this.root.add(spill);
  const scriptSpill=new T.PointLight(0xff5297,13,5,2);scriptSpill.position.set(0,1.3,.65);this.root.add(scriptSpill);

 }
 buildTitle(wordmarks){
  // Fixed artwork from a lighter weight of the heading family and a semibold sign-painter script.
  // Preserve the original lettering proportions, kerning, and connected strokes.
  const face=new T.MeshBasicMaterial({color:0xffedcc});
  const sides=this.material(0xb34e38,.25,.4);
  for(const word of wordmarks.words){
   const script=word.text==='Table',rowY=script?.32:-1.5;
   const [minX,minY,width,height]=word.bounds,scale=Math.min((script?6.8:8.5)/width,(script?1.95:1.72)/height);
   const x=v=>(v-minX-width/2)*scale,y=v=>(v-minY)*scale+rowY;
   word.glyphs.forEach((commands,index)=>{
    const path=new T.ShapePath();
    for(const [op,...v] of commands){
     if(op==='M')path.moveTo(x(v[0]),y(v[1]));
     if(op==='L')path.lineTo(x(v[0]),y(v[1]));
     if(op==='Q')path.quadraticCurveTo(x(v[0]),y(v[1]),x(v[2]),y(v[3]));
     if(op==='C')path.bezierCurveTo(x(v[0]),y(v[1]),x(v[2]),y(v[3]),x(v[4]),y(v[5]));
     if(op==='Z')path.currentPath.closePath();
    }
    const outer=path.subPaths.reduce((a,b)=>Math.abs(T.ShapeUtils.area(a.getPoints(16)))>Math.abs(T.ShapeUtils.area(b.getPoints(16)))?a:b);
    const shapes=path.toShapes(!T.ShapeUtils.isClockWise(outer.getPoints(16)));
    const geo=new T.ExtrudeGeometry(shapes,{depth:.115,curveSegments:16,bevelEnabled:true,bevelThickness:.012,bevelSize:script?.014:.009,bevelSegments:2});
    geo.translate(0,0,.08);const mesh=new T.Mesh(geo,[face,sides]);mesh.name=`diner-letter-${word.text}-${index}`;mesh.userData.sourceFace=word.sourceFace;this.root.add(mesh);
    for(const shape of shapes)for(const contour of [shape,...shape.holes]){const points=contour.getPoints(16).map(v=>new T.Vector3(v.x,v.y,.22));if(points.length<3)continue;points.push(points[0].clone());if(script){const halo=this.tube(points.map(p=>new T.Vector3(p.x,p.y,p.z-.022)),.039,this.neonPink,false);halo.name='table-pink-light';const core=this.tube(points,.014,this.neonScriptCore,false);core.name='table-yellow-core';}else{const stroke=this.tube(points,.042,this.neonStakes,false);stroke.name='stakes-neon-stroke';}for(let i=0;i<points.length;i+=2)this.emitters.push(points[i].clone());}
   });
  }
  const star=new T.Shape();for(let i=0;i<10;i++){let a=i*Math.PI/5+Math.PI/2,r=i%2?.065:.16;const x=Math.cos(a)*r,y=Math.sin(a)*r;i?star.lineTo(x,y):star.moveTo(x,y);}const geo=new T.ShapeGeometry(star);for(const x of [-.47,0,.47]){const m=new T.Mesh(geo,this.neonCream);m.position.set(x,-2.1,.05);this.root.add(m);}
 }
 buildParticles(){
  this.count=320;this.positions=new Float32Array(this.count*3);this.sparkColors=new Float32Array(this.count*3);this.ages=new Float32Array(this.count);this.sizes=new Float32Array(this.count);this.particles=Array.from({length:this.count},()=>({p:new T.Vector3(),v:new T.Vector3(),life:0,total:1}));this.positions.fill(0);const g=new T.BufferGeometry();g.setAttribute('position',new T.BufferAttribute(this.positions,3));g.setAttribute('sparkColor',new T.BufferAttribute(this.sparkColors,3));g.setAttribute('alpha',new T.BufferAttribute(this.ages,1));g.setAttribute('size',new T.BufferAttribute(this.sizes,1));
  const m=new T.ShaderMaterial({transparent:true,depthWrite:false,blending:T.AdditiveBlending,toneMapped:false,uniforms:{pixelRatio:{value:this.renderer.getPixelRatio()}},vertexShader:`attribute float alpha;attribute float size;attribute vec3 sparkColor;varying vec3 vColor;varying float vAlpha;uniform float pixelRatio;void main(){vColor=sparkColor;vAlpha=alpha;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_Position=projectionMatrix*mv;gl_PointSize=size*pixelRatio*(18.0/-mv.z);}`,fragmentShader:`varying vec3 vColor;varying float vAlpha;void main(){vec2 uv=gl_PointCoord-.5;float r=length(uv);float core=1.0-smoothstep(.04,.22,r);float glow=exp(-r*r*20.0);float a=(core+glow*.5)*vAlpha;gl_FragColor=vec4(vColor*2.5,a);}`});this.points=new T.Points(g,m);this.points.frustumCulled=false;this.root.add(this.points);
  this.trailColors=new Float32Array(this.count*6);this.trailPositions=new Float32Array(this.count*6);const trails=new T.BufferGeometry();trails.setAttribute('color',new T.BufferAttribute(this.trailColors,3));trails.setAttribute('position',new T.BufferAttribute(this.trailPositions,3));this.trails=new T.LineSegments(trails,new T.LineBasicMaterial({vertexColors:true,transparent:true,opacity:.6,blending:T.AdditiveBlending,depthWrite:false,toneMapped:false}));this.trails.frustumCulled=false;this.root.add(this.trails);
 }
 spark(amount=40){if(!this.emitters.length||!this.options.sparks||this.options.reducedMotion)return;const source=this.emitters[Math.floor(Math.random()*this.emitters.length)],colorOffset=Math.floor(Math.random()*SPARK_COLORS.length);for(let i=0;i<amount;i++){const idx=this.cursor++%this.count,p=this.particles[idx],a=Math.random()*Math.PI*2,speed=.8+Math.random()*2.5;p.p.copy(source);p.v.set(Math.cos(a)*speed,Math.sin(a)*speed+.8,.2+Math.random()*.6);p.life=p.total=.4+Math.random()*.7;this.sizes[idx]=1.5+Math.random()*3;const color=new T.Color(SPARK_COLORS[(i+colorOffset)%SPARK_COLORS.length]);color.toArray(this.sparkColors,idx*3);color.toArray(this.trailColors,idx*6);color.toArray(this.trailColors,idx*6+3);}}
 configure(options){Object.assign(this.options,options);this.bloomPass.strength=this.options.bloom;if(!this.options.sparks||this.options.reducedMotion)for(const p of this.particles)p.life=0;}
 resize(){const w=this.container.clientWidth,h=this.container.clientHeight;if(!w||!h)return;this.renderer.setSize(w,h);this.composer?.setSize(w,h);this.camera.aspect=w/h;this.camera.position.z=Math.max(15.9,10.95/(2*Math.tan(T.MathUtils.degToRad(17.5))*this.camera.aspect));this.camera.updateProjectionMatrix();}
 tick(now){if(this.disposed)return;const elapsed=Math.max(0,(now-(this.last||now))/1000),dt=Math.min(elapsed,.04);this.last=now;if(document.hidden)return;this.time+=elapsed;
  if(!this.options.reducedMotion){this.root.rotation.y=T.MathUtils.lerp(this.root.rotation.y,-.045+this.pointer.x*.075,.035);this.root.rotation.x=T.MathUtils.lerp(this.root.rotation.x,this.pointer.y*.025,.035);if(this.time>this.nextBurst){this.spark(18+Math.floor(Math.random()*22));this.nextBurst=this.time+nextSparkDelay();}this.warm.intensity=65+Math.sin(this.time*2.5)*2;}else{this.root.rotation.set(0,-.045,0);this.warm.intensity=65;}
  for(let i=0;i<this.count;i++){const p=this.particles[i];if(p.life>0){p.life-=dt;p.v.y-=3.7*dt;p.p.addScaledVector(p.v,dt);}const alive=Math.max(0,p.life/p.total);this.ages[i]=alive;this.positions.set([p.p.x,p.p.y,p.p.z],i*3);const tail=.022*alive;this.trailPositions.set([p.p.x,p.p.y,p.p.z,p.p.x-p.v.x*tail,p.p.y-p.v.y*tail,p.p.z-p.v.z*tail],i*6);}
  this.points.geometry.attributes.sparkColor.needsUpdate=true;this.trails.geometry.attributes.color.needsUpdate=true;this.points.geometry.attributes.position.needsUpdate=true;this.points.geometry.attributes.alpha.needsUpdate=true;this.points.geometry.attributes.size.needsUpdate=true;this.trails.geometry.attributes.position.needsUpdate=true;this.composer.render(dt);
 }
 dispose(){this.disposed=true;this.renderer.setAnimationLoop(null);this.resizeObserver.disconnect();const geometries=new Set(),materials=new Set();this.scene.traverse(o=>{if(o.geometry)geometries.add(o.geometry);if(o.material)for(const m of [o.material].flat())materials.add(m);});for(const g of geometries)g.dispose();for(const m of materials)m.dispose();for(const pass of this.composer.passes)pass.dispose?.();this.composer.dispose();this.renderer.dispose();this.renderer.domElement.remove();}
}
