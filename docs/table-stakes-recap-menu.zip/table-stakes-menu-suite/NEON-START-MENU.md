# TABLE STAKES — Neon restaurant start menu

Open **http://127.0.0.1:5194/start.html** after starting this folder with `npm start`. The original three-step setup stays at `index.html`. All scripts, font data, models and Three.js dependencies are local; no installation or CDN is required.

The sign is real Three.js geometry: extruded bold lettering, widely spaced, gently slanted cream enamel capitals with thin warm cream and coral neon edging, a cyan perimeter, a metal backing board, brickwork, warm bulbs and actual bloom postprocessing. Pooled sparkler particles emit from points on the lettering, travel with gravity, and leave short additive trails. Automatic multicolor bursts occur every 3–5 seconds, with aqua, coral pink, gold, cream and lavender particles and matching trails. Click the sign or “Give it a spark” for a burst.

## Included menu options

- **Play Online:** unavailable, matching the supplied screen.
- **Invite Opponent:** opens a private-match explanation. No invitation is sent and no room is created.
- **Play vs Bot:** opens the existing three-step setup preview. A bot match is not simulated here.
- **Join Private Match:** accepts a room code or invite token and shows the requested token in a connection placeholder. It does not look up or join a server room.
- **How to Play:** opens an overview of menu setup, restaurant service and rivalry.
- **Settings:** live controls for title sparks, reduced motion and bloom. Values are saved only in this browser’s local storage.

This is a separate local preview. The live Table Stakes game has not been edited. Private-match actions also dispatch `table-stakes:action` document events with `{ type: 'invite' }` or `{ type: 'join', token }`. A `play-bot` event fires before navigation. Replace the handlers in `src/start.js` when wiring the menu into the real game client; these events alone do not provide networking.

## Reuse the neon sign

`src/neon-sign.js` exports `NeonRestaurantSign`. It owns a scene, renderer, camera, animation loop, resize observer, particle pool and bloom compositor. Put it inside an element with explicit width and height, and supply an import map for `three` and `three/addons/` (as in `start.html`).

```js
import { NeonRestaurantSign } from './src/neon-sign.js';

const sign = new NeonRestaurantSign(document.querySelector('#sign-stage'), {
  reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches,
  sparks: true,
  bloom: 0.6,
  // Optional: wordmarksUrl, otherwise uses the bundled title artwork JSON.
});
await sign.ready;
sign.spark(60);
sign.configure({ bloom: 0.6, reducedMotion: false, sparks: true });
// Optional pointer parallax: normalized coordinates from -1 to 1.
sign.pointer.set(0.2, 0);
// On permanent teardown:
sign.dispose();
```

For integration into an existing renderer, adapt the scene-building methods and add the sign group, particle update and bloom pass to the game’s own rendering loop. Avoid creating a separate renderer for every sign. This packaged class deliberately provides a complete isolated menu scene.

The pool has 320 particles; pixels are capped at 1.75 device pixel ratio. Reduced motion suppresses sparks and pointer movement. The fallback title and HTML menu remain available without WebGL. Three.js is version 0.180.0. Its license and the earlier Helvetiker font license are under `vendor/`. The current sign uses fixed word artwork in `vendor/fonts/title-wordmarks.json`, traced from locally available lettering; it does not bundle a reusable font file.

## Verification

`npm test` covers the original setup rules plus bundled sign module resolution, generated title geometry and dimensions, spark origins on actual letter contours, bounded pool size, reduced-motion behavior, spark disabling, and bloom settings. HTTP checks confirm the menu, modules and font can be served.

The browser-control transport was unavailable during this addition, so the new menu has not been visually inspected or exercised in a browser by the assistant. Shader compilation and final GPU appearance still require a live browser check. The original setup flow was browser-tested in the preceding delivery.

Diner revision: default bloom reduced from 0.8 to 0.5, radius reduced from 0.55 to 0.3, and neon intensity reduced. Existing browser settings migrate once to the softer glow; subsequent manual adjustments are preserved. Reduced motion still suppresses sparks. Automatic burst timing uses elapsed seconds independently of the capped particle physics step.

Typography revision 3: “STAKES” uses Avenir Next Condensed Heavy Italic, the same face explicitly selected by the large menu headings. “Table” uses SignPainter HouseScript Semibold. Original word proportions and kerning are preserved in the 3D outlines. Bloom rises slightly from 0.5 to 0.6 (existing preferences receive a one-time +0.1 adjustment), and the cyan perimeter tube radius increases from 0.023 to 0.055. Automatic multicolor sparks remain on the 3–5 second schedule.

Revision 4: a rounded rose-pink enamel plaque sits behind “Table.” “STAKES” now uses Avenir Next Condensed Bold Italic (one weight lighter than Heavy), with its letter-outline tube radius increased from 0.011 to 0.023. Ten warm marquee bulbs extend down each side. Overall bloom, the blue perimeter, and automatic multicolor spark timing are preserved.

Revision 5: removed the solid pink plaque. “Table” now blends a pink outer glow with a warm yellow neon core, plus pink light spill. “STAKES” has a 0.042-radius stroke and dedicated high-intensity neon material for substantially stronger bloom. A continuous curved pink-red neon flourish replaces the bottom brackets, with its own light spill. Extra emission is localized to those elements; user bloom settings and the 3–5 second spark cycle are preserved.
