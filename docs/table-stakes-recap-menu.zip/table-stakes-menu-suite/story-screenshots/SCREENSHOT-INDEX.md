# Recap screenshot and story index

These are actual browser captures of the standalone Three.js recap preview at a 1032 × 824 CSS-pixel viewport. Some screenshots are scrolled to show an entire panel. Use the PNGs as visual references and the behavior below as suggested acceptance criteria, not as a claim that live-game integration is complete.

**Data:** Screenshots 01 and 03–09 use the supplied recap PDF values. Screenshots 02 and 10 use clearly labeled illustrative win data. Animation is frozen in screenshots; run `npm start` and open `/recap.html` to inspect motion and interactions. The original PDF is not redistributed.

## 01 — Loss / opening highlights

[01-loss-highlights.png](01-loss-highlights.png)

As a player, I can understand the result and my biggest improvement immediately.

**Acceptance cues:** Show the loss heading, scores and friendly frowning 3D tomato chef. Give the best-selling dish and lead takeaway the largest cards. Caesar Salad and Smash Burger each sold six; label the tie. Keep detailed statistics behind their own section.

## 02 — Win / opening highlights

[02-win-highlights.png](02-win-highlights.png)

As a winner, I get a celebratory result with a clear menu star.

**Acceptance cues:** Show the win heading and happy 3D chef. Feature Smash Burger at 18 sales in this illustrative fixture, with smaller supporting dishes. The demo badge must remain visible; these are sample numbers, not the PDF result.

## 03 — Next shift / saved game plan

[03-next-shift-coaching.png](03-next-shift-coaching.png)

As a player, I can choose actionable lessons for my next shift.

**Acceptance cues:** Show one prominent takeaway, its recommended action and selectable topic rows. Add/remove updates the saved checkmark and playbook. Download exports chosen notes. Arrow controls cycle takeaways; disable them when only one exists. Notes persist for the page session.

## 04 — Temporary staff / evidence dialog

[04-staffing-evidence.png](04-staffing-evidence.png)

As a player, I can see the evidence behind a recommendation.

**Acceptance cues:** Open the supporting dialog from the takeaway. Show $38 total temporary labor, split into $18 hire fees and $20 wages, with zero recorded tasks. Explain that this cost is already included in expenses and does not alone prove why the match was lost. Close returns to the panel.

## 05 — Menu stars / 3D dish showcase

[05-menu-stars.png](05-menu-stars.png)

As a player, I can inspect my most popular dishes at a glance.

**Acceptance cues:** Display the featured food as a large live 3D model and other sold dishes as smaller selectable models. Clicking one updates its title, model and metrics. Preserve co-best-seller labels for ties. Keep fastest fulfillment and unit margin distinct from sales volume.

## 06 — The numbers / business and service

[06-financial-summary.png](06-financial-summary.png)

As a player, I can read my financial result without a wall of statistics.

**Acceptance cues:** Prioritize net profit, revenue and expenses. Show temporary staff and promotion costs as included subsets, not additional deductions. For the PDF fixture, $174.60 minus $544.40 equals −$369.80. Show rival comparison and a separate service card with guests, satisfaction and wait.

## 07 — Detailed scorecard / on demand

[07-full-scorecard.png](07-full-scorecard.png)

As a player, I can inspect a full comparison when I want the detail.

**Acceptance cues:** Open a scrollable dialog with You/Rival columns. Keep extra management information expandable below the visible table. Missing PDF score components and truncated later turning points must not be invented. Closing restores the current section.

## 08 — Arrange board / coaching moved first

[08-rearrangeable-board.png](08-rearrangeable-board.png)

As a player, I can choose which recap categories appear first.

**Acceptance cues:** Arrange Board reveals independent category cards, drag handles, move arrows and Reset order. This screenshot shows coaching swapped ahead of dishes. Dragging swaps the source and target; arrows offer a keyboard/touch alternative. Disable arrows at their boundaries. Finish Arranging returns to the focused view.

## 09 — Arrange board / lower categories

[09-board-service-and-finances.png](09-board-service-and-finances.png)

As a player, I can rearrange the service and finance categories too.

**Acceptance cues:** The lower service and finance cards use the same move controls as the food and coaching cards. Swapping changes order without changing match values or saved tips. Reset order restores dishes, coaching, service, then finances. Layout lasts for the page session.

## 10 — Win / celebration in motion

[10-victory-fireworks.png](10-victory-fireworks.png)

As a player, a win gets a short animated celebration.

**Acceptance cues:** Emit colored round particles and trails for an eight-second spawning window, then let remaining particles expire. Replay Reveal restarts the panel entrances and celebration. Respect reduced motion and Motion Off: no fireworks or moving 3D subjects. Screenshot freezes one moment; inspect the preview for timing.

