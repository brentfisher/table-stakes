import assert from 'node:assert/strict';
import {registerHooks} from 'node:module';
import {readFile} from 'node:fs/promises';
registerHooks({resolve(specifier,context,next){return specifier==='three'?{url:new URL('../vendor/three.module.js',import.meta.url).href,shortCircuit:true}:specifier.startsWith('three/addons/')?{url:new URL('../vendor/addons/'+specifier.slice(13),import.meta.url).href,shortCircuit:true}:next(specifier,context);}});
const T=await import('three');
const {NeonRestaurantSign,nextSparkDelay,SPARK_COLORS}=await import('../src/neon-sign.js');
const wordmarks=JSON.parse(await readFile(new URL('../vendor/fonts/title-wordmarks.json',import.meta.url),'utf8')); 
const sign=Object.create(NeonRestaurantSign.prototype);
Object.assign(sign,{root:new T.Group(),emitters:[],options:{sparks:true,reducedMotion:false,bloom:.8},cursor:0,renderer:{getPixelRatio:()=>1},bloomPass:{strength:.8}});
sign.buildFacade();sign.buildTitle(wordmarks);sign.buildParticles();
assert(sign.emitters.length>100,'Letter contours provide spark emission sites');
for(const p of sign.emitters){assert(p.toArray().every(Number.isFinite));assert(p.x>=-4.4&&p.x<=4.4,'Title fits sign width');assert(p.y>-2.48&&p.y<2.48,'Title fits sign height');}
const originalRandom=Math.random;
try {for(const value of [0,.5,.999999]){Math.random=()=>value;assert.equal(nextSparkDelay(),3+value*2);}}finally{Math.random=originalRandom;}
assert.equal(sign.root.children.filter(o=>o.name.startsWith('diner-letter-')).length,11);
assert(sign.root.children.filter(o=>o.name.startsWith('diner-letter-')).every(o=>o.material[0].isMeshBasicMaterial),'Solid enamel faces remain legible without bloom');
sign.spark(40);assert.equal(sign.particles.filter(p=>p.life>0).length,40);assert(sign.particles.slice(0,40).every(p=>sign.emitters.some(e=>e.equals(p.p))),'Sparks originate on neon letter contours');
const burstColors=new Set();
for(let i=0;i<40;i++){const color=Array.from(sign.sparkColors.slice(i*3,i*3+3));assert(color.every(Number.isFinite));burstColors.add(color.join(','));assert.deepEqual(Array.from(sign.trailColors.slice(i*6,i*6+3)),color);}
assert.equal(burstColors.size,SPARK_COLORS.length,'Every burst mixes the full five-color palette with matching trails');
for(let i=0;i<20;i++)sign.spark(75);assert.equal(sign.particles.length,320,'Particle pool remains bounded');
sign.configure({reducedMotion:true});assert(sign.particles.every(p=>p.life===0));sign.spark(40);assert(sign.particles.every(p=>p.life===0),'Reduced motion prevents bursts');
sign.configure({reducedMotion:false,sparks:false,bloom:0});sign.spark(40);assert(sign.particles.every(p=>p.life===0));assert.equal(sign.bloomPass.strength,0);
sign.configure({sparks:true});sign.spark(1);assert.equal(sign.particles.filter(p=>p.life>0).length,1);
let meshes=0,triangles=0;sign.root.traverse(o=>{if(o.isMesh){meshes++;const position=o.geometry.attributes.position;for(const v of position.array)assert(Number.isFinite(v));triangles+=(o.geometry.index?.count??position.count)/3;}});
console.log(`PASS: bundled module resolution; title geometry (${meshes} meshes, ${Math.round(triangles)} base triangles); contour spark origins; bounded 320-particle pool; reduced motion; spark toggle; bloom setting; 3–5 second schedule; five-color bursts and trails; solid diner lettering.`);
