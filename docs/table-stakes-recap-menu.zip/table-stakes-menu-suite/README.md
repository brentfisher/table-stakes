# Table Stakes — Menu preview suite

Includes the neon **start menu** (`start.html`), three-step **setup** (`index.html`), and bright animated **recap** (`recap.html`). For the newest recap, read [RECAP-PREVIEW.md](RECAP-PREVIEW.md). The [screenshot gallery](story-screenshots/index.html) and [story index](story-screenshots/SCREENSHOT-INDEX.md) contain 10 numbered PNG references and suggested acceptance criteria.

A standalone, interactive Three.js setup preview with an original competitive hero-selection visual style: angled typography, warm orange selection signals, cool showroom lighting, rotating 3D subjects, and explicit stage confirmations.

## Run

From this folder, run `npm start`, or `python3 -m http.server 5194 --bind 127.0.0.1`. Open http://127.0.0.1:5194/. If that port is occupied, choose another port in the Python command. The running preview supplied with this delivery already uses port 5194.

No package installation, build, CDN, API key, or Blender connection is needed. Serve over HTTP rather than opening index.html directly. All models and Three.js modules are bundled.

## Play through the setup

1. **Menu showroom:** inspect live 3D food cards, add exactly three mains and optionally up to two add-ons. Orange borders and checkmarks confirm selection. Confirm & Next locks the stage.
2. **Crew and equipment bay:** use the Crew, Upgrade, and Policy tabs to assign the two workers, choose one opening upgrade from the full catalog, and choose a free policy. House Special requires a dish target. Confirm & Next records these choices.
3. **Opening counter:** price the chosen dishes, adjust starting stock, and review the opening. Confirm & Ready shows the completed lineup. Export Setup JSON downloads the corresponding game setup payload.

Back navigation keeps choices. Editing a selection invalidates affected confirmation state. A removed House Special target must be replaced. No data is sent to a game server; refresh resets the preview. This is a setup interaction prototype, not a simulated restaurant shift.

## Game rules and integration

The copied catalog and pure setup-rule modules come from the local Table Stakes project. Nachos is a main because its `snack` category is not an add-on category. Espresso and Cheesecake are the two add-ons. The preview preserves the $600 cash budget, dish price bounds, 0–80 whole stock units per ingredient, valid staff posts, opening upgrade choices, and policy target checks.

Recommended inventory uses the shared allocation function: up to 60% of cash after upgrade cost, targeting 45 servings per dish, subject to ingredient caps and proportional affordability. Review stock again after changing a previously confirmed menu or upgrade; the preview preserves edits rather than silently replacing them.

`src/state.js` owns the setup and generates the existing `SetupSubmitPayload` shape. `src/app.js` renders the UI. `src/scene.js` renders the main showroom and food thumbnails through a single WebGL canvas with scissored viewports. Browser export is the integration handoff; server-side validation remains necessary in a live game.

## Assets and rendering

- All 26 GLB models from the earlier Blender food library are included. This preview directly uses the eight dish models.
- Crew and equipment display models are generated in Three.js. They are concept models rather than production character rigs.
- PBR materials, directional shadow maps, hemisphere and rim lighting, tone mapping, animated focus, and rotate controls.
- Original interface styling; no Overwatch logos, game assets, or fonts are bundled.
- Responsive CSS, keyboard operable controls, visible focus, reduced motion support, and validation feedback. 3D rendering requires WebGL; selection controls remain usable if renderer creation fails.
- Three.js 0.180.0 license is in `vendor/THREE-LICENSE.txt`.

## Verification

Run `npm test`. Tests cover selection limits, Nachos classification, step gates, backward navigation, House Special invalidation, price bounds, inventory limits, affordability, worker posts, and export shape.

The local browser flow was exercised through final confirmation with a changed staff post, equipped upgrade, targeted House Special, edited price, invalid-price and invalid-stock gates, and recommended stock. The browser reported no warning/error logs during that flow. Screenshots of the three stages are in `previews/`.
